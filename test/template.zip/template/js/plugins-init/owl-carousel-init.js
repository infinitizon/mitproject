var basicCarousel = $("#basic-carousel");

basicCarousel.owlCarousel({
    loop:true,
    nav:true,
    responsive:{
        0:{
            items:1
        }
    }
})